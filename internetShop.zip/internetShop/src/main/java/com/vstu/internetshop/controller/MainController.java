package com.vstu.internetshop.controller;

import com.vstu.internetshop.dao.OrderDao;
import com.vstu.internetshop.dao.ProductDao;
import com.vstu.internetshop.entity.OrderEntity;
import com.vstu.internetshop.entity.ProductEntity;
import com.vstu.internetshop.util.JavaFxUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.TableCell;

import java.math.BigDecimal;
import java.net.URL;
import java.util.ResourceBundle;

import static com.vstu.internetshop.service.UserSession.SESSION;

public class MainController implements Initializable {

    private final ProductDao productDao = new ProductDao();
    private final OrderDao orderDao = new OrderDao();

    @FXML
    private TableView<ProductEntity> productsTable;

    @FXML
    private TableColumn<ProductEntity, String> descriptionColumn;

    @FXML
    private TableColumn<ProductEntity, String> nameColumn;

    @FXML
    private TableColumn<ProductEntity, BigDecimal> priceColumn;

    @FXML
    private TableColumn<ProductEntity, String> imageColumn;

    @FXML
    private Button adminBtn;

    @FXML
    private Label userLabel;

    @FXML
    private ImageView logoImageView;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        if (imageColumn != null) {
            imageColumn.setCellValueFactory(new PropertyValueFactory<>("imagePath"));
            imageColumn.setCellFactory(col -> new TableCell<>() {
                private final ImageView imageView = new ImageView();
                {
                    imageView.setFitHeight(50);
                    imageView.setFitWidth(50);
                    imageView.setPreserveRatio(true);
                }
                @Override
                protected void updateItem(String imagePath, boolean empty) {
                    super.updateItem(imagePath, empty);
                    if (empty || imagePath == null || imagePath.isBlank()) {
                        setGraphic(null);
                    } else {
                        try {
                            Image image = new Image("file:" + imagePath);
                            imageView.setImage(image);
                            setGraphic(imageView);
                        } catch (Exception e) {
                            setGraphic(null);
                        }
                    }
                }
            });
        }
        fulfillTable();

        if (SESSION.getUser().getRoles().stream().anyMatch(role -> "ADMIN".equals(role.getName()))) {
            adminBtn.setDisable(false);
            adminBtn.setOpacity(1);
            userLabel.setText("Админ");
        } else {
            userLabel.setText("Пользователь");
        }

        try {
            Image logo = new Image(getClass().getResourceAsStream("/images/logo.jpg"));
            logoImageView.setImage(logo);
        } catch (Exception e) {
            System.out.println("Logo not found or cannot be loaded: " + e.getMessage());
        }
    }

    public void ordersHistoryBtnOnAction(ActionEvent e) {
        JavaFxUtil.moveToPage(e, "user-order-history.fxml");
    }

    public void currentOrderBtnOnAction(ActionEvent e) {
        if (SESSION.getOrder() == null) {
            return;
        }
        JavaFxUtil.moveToPage(e, "user-order.fxml");
    }

    public void addToOrderOnAction(ActionEvent e) {
        ProductEntity product = productsTable.getSelectionModel().getSelectedItem();
        if (product == null) {
            return;
        }
        if (SESSION.getOrder() == null) {
            OrderEntity order = orderDao.createOrder(SESSION.getUser())
                    .orElseThrow(() -> new RuntimeException("Failed to get order"));
            SESSION.setOrder(order);
        }
        productDao.addProductToOrder(product, SESSION.getOrder());
        fulfillTable();
    }

    public void logoutBtnOnAction(ActionEvent e) {
        SESSION.setUser(null);
        SESSION.setOrder(null);
        JavaFxUtil.moveToPage(e, "login.fxml");
    }

    public void adminBtnOnAction(ActionEvent e) {
        JavaFxUtil.moveToPage(e, "admin.fxml");
    }

    private void fulfillTable() {
        productsTable.setItems(FXCollections.observableList(productDao.getProducts(null)));
    }

}