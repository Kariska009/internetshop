package com.vstu.internetshop.controller;

import com.vstu.internetshop.dao.ProductDao;
import com.vstu.internetshop.dto.ProductStatus;
import com.vstu.internetshop.entity.ProductEntity;
import com.vstu.internetshop.service.UserSession;
import com.vstu.internetshop.util.JavaFxUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class AdminCreateProductController {
    private final ProductDao productDao = new ProductDao();
    private String imagePath;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField priceTextField;

    @FXML
    private Label fullfillFiledsLabel;

    @FXML
    private ImageView productImageView;

    @FXML
    void uploadImageBtnOnAction(ActionEvent e) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Выберите изображение");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Изображения", "*.png", "*.jpg", "*.jpeg")
        );

        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            try {
                Path imagesDir = Paths.get("src/main/resources/images/products");
                if (!Files.exists(imagesDir)) {
                    Files.createDirectories(imagesDir);
                }

                String fileName = System.currentTimeMillis() + "_" + selectedFile.getName();
                Path targetPath = imagesDir.resolve(fileName);
                Files.copy(selectedFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

                imagePath = "src/main/resources/images/products/" + fileName;

                Image image = new Image(new FileInputStream(targetPath.toFile()));
                productImageView.setImage(image);
            } catch (IOException ex) {
                fullfillFiledsLabel.setText("Ошибка при загрузке изображения");
                fullfillFiledsLabel.setOpacity(1);
            }
        }
    }

    @FXML
    void cancelBtnOnAction(ActionEvent e) {
        JavaFxUtil.moveToPage(e, "admin-products.fxml");
    }

    @FXML
    void createProductBtnOnAction(ActionEvent e) {
        if (isFieldsBlank()) {
            fullfillFiledsLabel.setText("Все обязательные поля должны быть заполнены");
            fullfillFiledsLabel.setOpacity(1);
            return;
        }
        if (!isNumeric(priceTextField.getText())) {
            fullfillFiledsLabel.setText("Цена должно быть числом");
            fullfillFiledsLabel.setOpacity(1);
            return;
        }

        try {
            productDao.createProduct(new ProductEntity(
                    null,
                    nameTextField.getText(),
                    new BigDecimal(priceTextField.getText()),
                    descriptionTextField.getText(),
                    UserSession.SESSION.getUser(),
                    ProductStatus.AVAILABLE,
                    imagePath
            ));
            JavaFxUtil.moveToPage(e, "admin-products.fxml");
        } catch (Exception ex) {
            fullfillFiledsLabel.setText("Ошибка при создании товара: " + ex.getMessage());
            fullfillFiledsLabel.setOpacity(1);
            System.out.println(ex.getMessage());
        }
    }

    private boolean isFieldsBlank() {
        return nameTextField.getText().isBlank() || priceTextField.getText().isBlank();
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}