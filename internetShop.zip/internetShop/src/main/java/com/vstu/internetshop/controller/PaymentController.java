package com.vstu.internetshop.controller;

import com.vstu.internetshop.dao.OrderDao;
import com.vstu.internetshop.dao.ProductDao;
import com.vstu.internetshop.dto.OrderStatus;
import com.vstu.internetshop.dto.ProductFilter;
import com.vstu.internetshop.entity.ProductEntity;
import com.vstu.internetshop.util.JavaFxUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import static com.vstu.internetshop.service.UserSession.SESSION;

public class PaymentController implements Initializable {

    private final OrderDao orderDao = new OrderDao();
    private final ProductDao productDao = new ProductDao();

    @FXML
    private TextField cardNumberField;

    @FXML
    private TextField expiryField;

    @FXML
    private TextField cvvField;

    @FXML
    private Label amountLabel;

    @FXML
    private Button payButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cardNumberField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cardNumberField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (newValue.length() > 16) {
                cardNumberField.setText(oldValue);
            }
            if (cardNumberField.getText().length() != 16) {
                cardNumberField.setStyle("-fx-border-color: red;");
            } else {
                cardNumberField.setStyle("");
            }
        });

        expiryField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                expiryField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (newValue.length() > 4) {
                expiryField.setText(oldValue);
            }
            if (expiryField.getText().length() != 4) {
                expiryField.setStyle("-fx-border-color: red;");
            } else {
                expiryField.setStyle("");
            }
        });

        cvvField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cvvField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (newValue.length() > 3) {
                cvvField.setText(oldValue);
            }
            if (cvvField.getText().length() != 3) {
                cvvField.setStyle("-fx-border-color: red;");
            } else {
                cvvField.setStyle("");
            }
        });

        calculateAndDisplayTotal();
    }

    private void calculateAndDisplayTotal() {
        ProductFilter filter = new ProductFilter();
        filter.setOrderId(SESSION.getOrder().getId());
        List<ProductEntity> products = productDao.getProducts(filter);
        
        BigDecimal total = products.stream()
                .map(ProductEntity::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        amountLabel.setText(total.toString());
    }

    public void payButtonOnAction(ActionEvent e) {
        boolean hasError = false;
        if (cardNumberField.getText().length() != 16) {
            cardNumberField.setStyle("-fx-border-color: red;");
            hasError = true;
        }
        if (expiryField.getText().length() != 4) {
            expiryField.setStyle("-fx-border-color: red;");
            hasError = true;
        }
        if (cvvField.getText().length() != 3) {
            cvvField.setStyle("-fx-border-color: red;");
            hasError = true;
        }
        if (hasError) {
            return;
        }

        // Обновляем статус заказа
        orderDao.updateOrder(SESSION.getOrder().getId(), OrderStatus.PROCESSING);
        SESSION.setOrder(null);
        JavaFxUtil.moveToPage(e, "main.fxml");
    }

    public void cancelButtonOnAction(ActionEvent e) {
        JavaFxUtil.moveToPage(e, "user-order.fxml");
    }
} 