package com.vstu.internetshop;

public class Main {

    public static void main(String[] args) {
        InternetShopApplication.main(args);
    }

}
